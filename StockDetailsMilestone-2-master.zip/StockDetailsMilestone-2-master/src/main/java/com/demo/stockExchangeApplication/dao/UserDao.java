package com.demo.stockExchangeApplication.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.demo.stockExchangeApplication.model.User;

public interface UserDao extends JpaRepository<User, Integer> {

	@Query(value="select id from user where email =email and password =password", nativeQuery=true)
	int loginuser(@Param("email") String email,@Param("password") String password);
}
